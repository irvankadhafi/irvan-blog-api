<template>
    <div class="container">
        <h1>{{post.title}}</h1>
        <hr>
        <div v-html="post.body"></div>
    </div>
</template>

<script>
export default {
    name: "Show",
    data(){
        return{
            post:[]
        }
    },
    mounted() {
        // console.log(this.$route.params)
        this.getPost();
    },
    methods:{
        async getPost(){
            let response = await axios.get('/posts/'+this.$route.params.postSlug)
            this.post = response.data.data
        }
    }
}
</script>
