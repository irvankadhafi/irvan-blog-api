<template>
    <div class="container">
        About Page
    </div>

</template>

<script>
    export default {

    }
</script>
